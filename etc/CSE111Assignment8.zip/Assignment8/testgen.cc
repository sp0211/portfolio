#include <iostream>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <unistd.h>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <string>

#include "cracker.h"

void generate() {
  int sockfd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
  char hostname[64];
  gethostname(hostname, sizeof(hostname));
  srand(time(nullptr));

  Message msg {
    "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789",
    "sphunjam",
    {}, htonl(3), {0}, 25565
  };
  strncpy(msg.hostname, hostname, 64);

  std::string hash1 = "WuxaoJbgzwuwQ";
  strncpy(msg.passwds[0], hash1.c_str(), hash1.length());

  std::string hash2 = "Uz8uY1RkTJzLs";
  strncpy(msg.passwds[1], hash2.c_str(), hash2.length());

  std::string hash3 = "YNNbxoodYqWaU";
  strncpy(msg.passwds[2], hash3.c_str(), hash3.length());

  struct sockaddr_in server_addr;
  bzero((char *) &server_addr, sizeof(server_addr));
  server_addr.sin_family = AF_INET;
  server_addr.sin_addr.s_addr = INADDR_ANY;
  server_addr.sin_port = htons(get_multicast_port());

  int ttl = 1;
  if (setsockopt(sockfd, IPPROTO_IP, IP_MULTICAST_TTL, (void *) &ttl, sizeof(ttl)) < 0) {
    exit(-1);
  }

  struct sockaddr_in multicast_addr;
  bzero((char *) &multicast_addr, sizeof(multicast_addr));
  multicast_addr.sin_family = AF_INET;
  multicast_addr.sin_addr.s_addr = get_multicast_address();
  multicast_addr.sin_port = htons(get_multicast_port());
  
  std::cout << "Sending message..." << std::endl;
  sendto(sockfd, &msg, sizeof(msg), 0, (struct sockaddr *) &multicast_addr, sizeof(multicast_addr));
  std::cout << "Message sent" << std::endl;

  close(sockfd);
}

void receive() {
  int sockfd = socket(AF_INET, SOCK_STREAM, 0);
  if (sockfd < 0) {
    exit(-1);
  }

  struct sockaddr_in server_addr;
  bzero((char *) &server_addr, sizeof(server_addr));
  server_addr.sin_family = AF_INET;
  server_addr.sin_addr.s_addr = INADDR_ANY;
  server_addr.sin_port = 25565;

  if (bind(sockfd, (struct sockaddr *) &server_addr, sizeof(server_addr)) < 0) {
    exit(-1);
  }

  listen(sockfd, 5);

  struct sockaddr_in client_addr;
  socklen_t len = sizeof(client_addr);

  int newsockfd = accept(sockfd, (struct sockaddr *) &client_addr, &len);
  if (newsockfd < 0) {
    exit(-1);
  }

  Message msg;
  bzero((char *) &msg, sizeof(msg));
  if (recv(newsockfd, &msg, sizeof(msg), 0) < 0) {
    exit(-1);
  }

  std::cout << "Response received. Returned cracked passwords: " << std::endl;
  for (unsigned int i = 0; i < 3; ++i) {
    std::cout << msg.passwds[i] << std::endl;
  }
  close(newsockfd);

  close(sockfd);
}

int main() {
  generate();
  receive();
  return 0;
}
