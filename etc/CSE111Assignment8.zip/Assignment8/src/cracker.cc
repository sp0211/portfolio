/*
 * Copyright (C) 2018-2022 David C. Harrison. All right reserved.
 *
 * You may not use, distribute, publish, or modify this code without 
 * the express written permission of the copyright holder.
 */

#include <iostream>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <unistd.h>
#include <crypt.h>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <string>
#include <functional>
#include <map>
#include <thread>
#include <future>
#include <chrono>

#include "cracker.h"

using namespace std;

string mastername = "thor";
char hostname[64];

typedef struct imessage {
    unsigned int completed;
    char pwd[5];
} InternalMessage;

void receive(Message &msg) {
    int sockfd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (sockfd < 0) {
        exit(-1);
    }

    struct sockaddr_in server_addr;
    bzero((char *) &server_addr, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(get_multicast_port());

    if (bind(sockfd, (struct sockaddr *) &server_addr, sizeof(server_addr)) < 0) {
        cout << strerror(errno) << endl;
        exit(-1);
    }

    struct ip_mreq multicastRequest;
    multicastRequest.imr_multiaddr.s_addr = get_multicast_address();
    multicastRequest.imr_interface.s_addr = htonl(INADDR_ANY);
    
    if (setsockopt(sockfd, IPPROTO_IP, IP_ADD_MEMBERSHIP, (void *) &multicastRequest, sizeof(multicastRequest)) < 0) {
        exit(-1);
    }
    
    gethostname(hostname, sizeof(hostname));
    if (strcmp(hostname, mastername.c_str()) == 0) {
        do {
            bzero((char *) &msg, sizeof(msg));
            recvfrom(sockfd, &msg, sizeof(msg), 0, NULL, 0);
        } while (strcmp(msg.cruzid, "sphunjam") != 0);
    }
    else {
        do {
            bzero((char *) &msg, sizeof(msg));
            recvfrom(sockfd, &msg, sizeof(msg), 0, NULL, 0);
        } while (strcmp(msg.hostname, mastername.c_str()) != 0);
    }

    cout << hostname << " received a message from " << msg.hostname << endl;

    close(sockfd);
}

void receiveInternal(Message &msg, unsigned int &found, const unsigned int pwdCount) {
    int sockfd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (sockfd < 0) {
        exit(-1);
    }

    struct sockaddr_in server_addr;
    bzero((char *) &server_addr, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(4000);

    if (bind(sockfd, (struct sockaddr *) &server_addr, sizeof(server_addr)) < 0) {
        cout << strerror(errno) << endl;
        exit(-1);
    }

    struct ip_mreq multicastRequest;
    multicastRequest.imr_multiaddr.s_addr = get_multicast_address();
    multicastRequest.imr_interface.s_addr = htonl(INADDR_ANY);
    
    if (setsockopt(sockfd, IPPROTO_IP, IP_ADD_MEMBERSHIP, (void *) &multicastRequest, sizeof(multicastRequest)) < 0) {
        exit(-1);
    }

    while (found < pwdCount) {
        InternalMessage imsg;
        bzero((char *) &imsg, sizeof(imsg));
        cout << "Awaiting internal message" << endl;
        recvfrom(sockfd, &imsg, sizeof(imsg), 0, NULL, 0);
        found = imsg.completed;
        if (strcmp(hostname, mastername.c_str()) == 0) {
            bzero(msg.passwds[found - 1], strlen(msg.passwds[found - 1]));
            strncpy(msg.passwds[found - 1], imsg.pwd, 5);
            cout << "Received password " << imsg.pwd << endl;
        }
    }

    close(sockfd);
}

void sendInternal(InternalMessage &imsg) {
    int sockfd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (sockfd < 0) {
        exit(-1);
    }

    struct sockaddr_in server_addr;
    bzero((char *) &server_addr, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(4000);

    int ttl = 1;
    if (setsockopt(sockfd, IPPROTO_IP, IP_MULTICAST_TTL, (void *) &ttl, sizeof(ttl)) < 0) {
        exit(-1);
    }

    struct sockaddr_in multicast_addr;
    bzero((char *) &multicast_addr, sizeof(multicast_addr));
    multicast_addr.sin_family = AF_INET;
    multicast_addr.sin_addr.s_addr = get_multicast_address();
    multicast_addr.sin_port = htons(4000);
  
    sendto(sockfd, &imsg, sizeof(imsg), 0, (struct sockaddr *) &multicast_addr, sizeof(multicast_addr));
    std::cout << "Sent an internal message" << std::endl;

    close(sockfd);
}

void crack(Message &msg, char hashes [][HASH_LENGTH + 1],  const unsigned int lo, const unsigned int hi) 
{
    const unsigned int pwdCount = ntohl(msg.num_passwds);
    const char* alphabet = msg.alphabet;
    unsigned int searchSpaceSize = hi - lo;
    unsigned int cores = thread::hardware_concurrency();
    thread threads[cores];
    unsigned int found = 0;

    for (unsigned int c = 0; c < cores; ++c) {
        unsigned int t_lo = lo + (unsigned int) (c * ceil(((double)searchSpaceSize / (double)cores)));
        unsigned int t_hi = lo + (unsigned int) ((c + 1) * ceil(((double)searchSpaceSize / (double)cores)));
        if (t_hi > hi) t_hi = hi;
        char* hash = hashes[0];

        threads[c] = thread([&pwdCount, &alphabet, &hashes, &hash, &found, t_lo, t_hi] {
            for (unsigned int i = t_lo; found < pwdCount; ++i) {
                hash = hashes[found];
                if (i >= t_hi) {
                    i = t_lo;
                }
                unsigned int c0 = (i / (ALPHABET_LEN * ALPHABET_LEN * ALPHABET_LEN)) % ALPHABET_LEN;
                unsigned int c1 = (i / (ALPHABET_LEN * ALPHABET_LEN)) % ALPHABET_LEN;
                unsigned int c2 = (i / ALPHABET_LEN) % ALPHABET_LEN;
                unsigned int c3 = i % ALPHABET_LEN;

                char pass[5] = {alphabet[c0], alphabet[c1], alphabet[c2], alphabet[c3], 0};
                char salt[3] = {hash[0], hash[1], 0};
                struct crypt_data data;
                bzero((char *) &data, sizeof(data));
                char* myHash = crypt_r(pass, salt, &data);

                if (strcmp(hash, myHash) == 0) {
                    ++found;
                    cout << "Cracked " << found << " passwords" << endl;

                    InternalMessage imsg;
                    bzero((char *)&imsg, sizeof(imsg));
                    strncpy(imsg.pwd, pass, 5);
                    imsg.completed = found;
                    sendInternal(imsg);
                }
            }
        });
    }

    thread listener = thread(receiveInternal, ref(msg), ref(found), ref(pwdCount));

    for (unsigned int d = 0; d < cores; ++d) {
        threads[d].join();
    }

    listener.join();
}

void crack(Message &msg) {
    cout << "Password count = " << ntohl(msg.num_passwds) << endl;

    unsigned int cardinality = ALPHABET_LEN * ALPHABET_LEN * ALPHABET_LEN * ALPHABET_LEN;
    unsigned int subCardinality = (unsigned int) ceil((double)cardinality / (double) 4);
    
    map<string, unsigned int> lo {
        {"noggin", 0},
        {"nogbad", subCardinality},
        {"thor", 2 * subCardinality},
        {"olaf", 3 * subCardinality},
    };

    map<string, unsigned int> hi {
        {"noggin", subCardinality},
        {"nogbad", 2 * subCardinality},
        {"thor", 3 * subCardinality},
        {"olaf", cardinality},
    };

    if (strcmp(hostname, mastername.c_str()) == 0) {
        Message msgCopy = msg;
        bzero(msgCopy.hostname, strlen(msgCopy.hostname));
        strncpy(msgCopy.hostname, hostname, 64);
        int multicast_sockfd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
        if (multicast_sockfd < 0) {
            exit(-1);
        }

        struct sockaddr_in server_addr;
        bzero((char *) &server_addr, sizeof(server_addr));
        server_addr.sin_family = AF_INET;
        server_addr.sin_addr.s_addr = INADDR_ANY;
        server_addr.sin_port = htons(get_multicast_port());

        if (bind(multicast_sockfd, (struct sockaddr *) &server_addr, sizeof(server_addr)) < 0) {
            exit(-1);
        }

        int ttl = 1;
        if (setsockopt(multicast_sockfd, IPPROTO_IP, IP_MULTICAST_TTL, (void *) &ttl, sizeof(ttl)) < 0) {
            exit(-1);
        }

        struct sockaddr_in multicast_addr;
        bzero((char *) &multicast_addr, sizeof(multicast_addr));
        multicast_addr.sin_family = AF_INET;
        multicast_addr.sin_addr.s_addr = get_multicast_address();
        multicast_addr.sin_port = htons(get_multicast_port());

        sendto(multicast_sockfd, &msgCopy, sizeof(msgCopy), 0, (struct sockaddr *) &multicast_addr, sizeof(multicast_addr));

        close(multicast_sockfd);
    }

    cout << "Server " << hostname << "searching range [" << lo[hostname] << ", " << hi[hostname] << ")" << endl; 
    crack(msg, msg.passwds, lo[hostname], hi[hostname]);
}

void send(Message &msg) {
    int sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) {
        exit(-1);
    }

    struct hostent *server = gethostbyname(msg.hostname);
    if (server == NULL) {
        exit(-1);
    }

    struct sockaddr_in server_addr;
    bzero((char *) &server_addr, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = msg.port;
    
    // Learned how to grab address from host name at 
    // https://gist.github.com/listnukira/4045628
    server_addr.sin_addr = *((struct in_addr*) server->h_addr_list[0]);

    if (connect(sockfd, (struct sockaddr *) &server_addr, sizeof(server_addr)) < 0) {
        exit(-1);
    }
    cout << "Connected" << endl;

    if (send(sockfd, &msg, sizeof(msg), 0) < 0) {
        exit(-1);
    }
    cout << "Sent" << endl;

    close(sockfd);
}

/**
 * @brief main function of yoiur cracker
 * 
 * No command line arguments are passed
 * 
 * @return int not checked by test harness
 */
int main() {
    Message msg;
    receive(msg);
    crack(msg);
    send(msg);
    return 0;
}
