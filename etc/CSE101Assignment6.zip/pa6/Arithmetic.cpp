/******************************************************************************
 * Name:       Sirapat "Poom" Phunjamaneechot                                 *
 * CruzID:     sphunjam                                                       *
 * PA6, CSE 101 Spring 2022                                                   *
 *                                                                            *
 * Arithmetic.cpp                                                             *
 * Source code for the Arithmetic program.                                    *
 ******************************************************************************/
 
 #include<iostream>
 #include<fstream>
 #include"BigInteger.h"
 
 using namespace std;
 
 int main(int argc, char* argv[]) {
 	if (argc < 3) {
 		cerr << "Too few arguments provided." << endl;
 		cerr << "Usage: ./Arithmetic <infile> <outfile>" << endl;
 		exit(EXIT_FAILURE);
 	} else if (argc > 3) {
 		cerr << "Too many arguments provided." << endl;
 		cerr << "Usage: ./Arithmetic <infile> <outfile>" << endl;
 		exit(EXIT_FAILURE);
 	}
 	
 	ifstream in;
 	ofstream out;
 	
 	in.open(argv[1]);
 	if (!in.is_open()) {
 		cerr << "Failed to open input file." << endl;
 		exit(EXIT_FAILURE);
 	}
 	
 	out.open(argv[2]);
 	if (!out.is_open()){
 		cerr << "Failed to open output file." << endl;
 		exit(EXIT_FAILURE);
 	}
 	
 	string lines[3];
 	
 	for (int i = 0; i < 3; i += 1) {
 		getline(in, lines[i]);
 	}
 	
 	BigInteger A = BigInteger(lines[0]);
 	BigInteger B = BigInteger(lines[2]);
 	
 	out << A << endl << endl;
 	
 	out << B << endl << endl;
 	
 	out << A + B << endl << endl;
 	
 	out << A - B << endl << endl;
 	
 	out << A - A << endl << endl;
 	
 	BigInteger three = BigInteger("3");
 	BigInteger two = BigInteger("2");
 	out << (three * A) - (two * B) << endl << endl;
 	
 	out << A * B << endl << endl;
 	
 	BigInteger ASquared = A * A;
 	out << ASquared << endl << endl;
 	
 	BigInteger BSquared = B * B;
 	out << BSquared << endl << endl;
 	
 	BigInteger nine = BigInteger("9");
 	BigInteger sixteen = BigInteger("16");
 	out << (nine * ASquared * ASquared) + (sixteen * BSquared * BSquared * B) << endl << endl;
 	
 	in.close();
 	out.close();
 	
 	return EXIT_SUCCESS;
 }
