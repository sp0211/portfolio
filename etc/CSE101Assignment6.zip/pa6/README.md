# Programming Assignment 6
## Files Included
| File Name      | Description |
| ----------      | ----------- |
| Arithmetic.cpp      | Source code for the Arithmetic program. |
| BigInteger.cpp      | Implementation of the BigInteger ADT. |
| BigInteger.h        | Interface for the BigInteger ADT. |
| BigIntegerTest.cpp  | Test client for the BigInteger ADT. |
| List.cpp            | Implementation of the List ADT. |
| List.h              | Interface for the List ADT. |
| ListTest.cpp        | Test client for the List ADT. |
| Makefile            | Rules for the make command. |
| README.md           | Markdown file listing submitted files with brief descriptions. |
