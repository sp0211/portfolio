/******************************************************************************
 * Name:       Sirapat "Poom" Phunjamaneechot                                 *
 * CruzID:     sphunjam                                                       *
 * PA6, CSE 101 Spring 2022                                                   *
 *                                                                            *
 * BigIntegerTest.cpp                                                         *
 * Test client for the BigInteger ADT                                         *
 ******************************************************************************/
 
#include<iostream>
#include<string>
#include<stdexcept>
#include"BigInteger.h"

using namespace std;

int main(){
   string a = "932571337101";
   string b = "-932571337101";
   string c = "+25430011089395";
   string d = "-25430011089395";
   string e = "0000000000000012345678955555";
   string f = "-0000000000000012345678955555";
   string g = "1000000000000012345678955555";
   string h = "-1000000000000012345678955555";
   string zero = "000000000000000000000000";
   string zeron = "-000000000000000000000000";

   //BigInteger N;
   BigInteger A = BigInteger(a);
   BigInteger B = BigInteger(b);
   if (!(A > B)) {
      cout << "Positive BigInteger somehow not greater than negative BigInteger" << endl;
      exit(EXIT_FAILURE);
   }
   if (!(B < A)) {
      cout << "Negative BigInteger somehow not less than positive BigInteger" << endl;
      exit(EXIT_FAILURE);
   }
   
   BigInteger C = BigInteger(c);
   BigInteger D = BigInteger(d);
   BigInteger E = BigInteger(e);
   BigInteger F = BigInteger(f);
   BigInteger G = BigInteger(g);
   BigInteger H = BigInteger(h);
   
   BigInteger z = BigInteger(zero);
   BigInteger zn = BigInteger(zeron);
   BigInteger zro = BigInteger();

   cout << endl;

   cout << "A = " << A << endl;
   cout << "B = " << B << endl;
   cout << "C = " << C << endl;
   cout << "D = " << D << endl;
   cout << "E = " << E << endl;
   cout << "F = " << F << endl;
   cout << "G = " << G << endl;
   cout << "H = " << H << endl;
   cout << "z = " << z << endl;
   cout << "zn = " << zn << endl;
   
   BigInteger ACopy = A;
   if (!(A == ACopy)) {
      cout << "Copy of A somehow not equal to A" << endl;
      exit(EXIT_FAILURE);
   }
   
   if (!(z >= zro) || !(z <= zro)) {
      cout << "BigInteger made with string of 0s somehow greater than or less than 0" << endl;
      exit(EXIT_FAILURE);
   }
   
   if (!(zn >= zro) || !(zn <= zro)) {
      cout << "BigInteger made with string of 0s with - at front somehow greater than or less than 0" << endl;
      exit(EXIT_FAILURE);
   }
   
   if (!(z == zro)) {
      cout << "BigInteger made with string of 0s somehow not 0" << endl;
      exit(EXIT_FAILURE);
   }
   
   if (!(zn == zro)) {
      cout << "BigInteger made with string of 0s with - at front somehow not 0" << endl;
      exit(EXIT_FAILURE);
   }
   
   if (!(A > zro)) {
      cout << "Positive BigInteger somehow not greater than 0" << endl;
   }
   
   if (!(B < zro)) {
      cout << "Negative BigInteger somehow not less than 0" << endl;
   }
   cout << endl;

   cout << "A + B = " << A + B << endl;
   cout << "B + A = " << B + A << endl;
   cout << "A - B = " << A - B << endl;
   cout << "B - A = " << B - A << endl;
   cout << "A * B = " << A * B << endl;
   cout << "B * A = " << B * A << endl << endl;
   BigInteger negate = BigInteger("-1");
   
   BigInteger nA = A;
   nA.negate();
   
   BigInteger nB = B;
   nB.negate();
   
   if (!(A * negate == nA)) {
      cout << "-1 * A somehow not equal to negation of A" << endl;
      exit(EXIT_FAILURE);
   }
   
   if (!(B * negate == nB)) {
      cout << "-1 * B somehow not equal to negation of B" << endl;
      exit(EXIT_FAILURE);
   }
   
   cout << "A + C = " << A + C << endl;
   cout << "C + A = " << C + A << endl;
   if (!((C + A) == (A + C))) {
      cout << "A + C somehow not equal to C + A" << endl;
   }
   cout << "A - C = " << A - C << endl;
   cout << "C - A = " << C - A << endl;
   cout << "A * C = " << A * C << endl;
   cout << "C * A = " << C * A << endl << endl;
   if (!((C * A) == (A * C))) {
      cout << "A * C somehow not equal to C * A" << endl;
   }
   
   cout << "B + D = " << B + D << endl;
   cout << "D + B = " << D + B << endl;
   cout << "B - D = " << B - D << endl;
   cout << "D - B = " << D - B << endl;
   cout << "B * D = " << B * D << endl;
   cout << "D * B = " << D * B << endl << endl;
   
   cout << "E + 0 = " << E + z << endl;
   cout << "F + 0 = " << F + zn << endl;
   cout << "0 + E = " << z + E << endl;
   cout << "0 + F = " << zn + F << endl << endl;
   
   cout << "G - 0 = " << G - z << endl;
   cout << "H - 0 = " << H - zn << endl;
   cout << "0 - G = " << z - G << endl;
   cout << "0 - H = " << zn - H << endl << endl;

   A += D;
   B -= A;
   C *= B;
   cout << "A (after increment by D) = " << A << endl;
   cout << "B (after decrement by A) = " << B << endl;
   cout << "C (after multiplying by B) = " << C << endl;
   cout << endl;

   cout << "A * B * C * D * E = " << A * B * C * D * E << endl << endl;
   cout << "A * B * C * D * 0 = " << A * B * C * D * zro << endl << endl;

   cout << endl;

   // test exceptions
   try{
      BigInteger Z = BigInteger("");
   }catch( std::invalid_argument& e ){
      cout << e.what() << endl;
      cout << "   continuing without interruption" << endl;
   }
   try{
      BigInteger Z = BigInteger("+");
   }catch( std::invalid_argument& e ){
      cout << e.what() << endl;
      cout << "   continuing without interruption" << endl;
   }
   try{
      BigInteger Z = BigInteger("12329837492387492837492$4982379487293847");
   }catch( std::invalid_argument& e ){
      cout << e.what() << endl;
      cout << "   continuing without interruption" << endl;
   }
   try{
      BigInteger Z = BigInteger("5298374902837409+82734098729287349827398");
   }catch( std::invalid_argument& e ){
      cout << e.what() << endl;
      cout << "   continuing without interruption" << endl;
   }

   cout << endl;

   return EXIT_SUCCESS;
}

