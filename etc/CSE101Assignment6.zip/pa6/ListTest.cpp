/******************************************************************************
 * Name:       Sirapat "Poom" Phunjamaneechot                                 *
 * CruzID:     sphunjam                                                       *
 * PA6, CSE 101 Spring 2022                                                   *
 *                                                                            *
 * ListTest.cpp                                                               *
 * Test client for the List ADT (PA6 version)                                 *
 ******************************************************************************/

#include<iostream>
#include<string>
#include<stdexcept>
#include"List.h"

using namespace std;

int main(){

	List A, B;
   
	for (int i = 1; i <= 15; i += 1) {
		A.insertBefore(i);
		B.insertAfter(i);
	}
	
	cout << "List A: " << A << endl;
	cout << "List A info:" << endl;
	cout << "    length:          " << A.length() << endl;
	cout << "    cursor position: " << A.position() << endl;
	cout << endl;
	
	cout << "List B: " << B << endl;
	cout << "List B info:" << endl;
	cout << "    length:          " << B.length() << endl;
	cout << "    cursor position: " << B.position() << endl;
	cout << endl;
	
	List C = A;
	cout << "List C: " << C << endl;
	cout << "List C info:" << endl;
	cout << "    length:          " << C.length() << endl;
	cout << "    cursor position: " << C.position() << endl;
	cout << endl;
	if (!(A == C)) {
		cout << "A and C somehow not equal even though C is a copy of A" << endl;
		exit(EXIT_FAILURE);
	}
	
	List Z = List(A);
	cout << "List Z: " << C << endl;
	cout << "List Z info:" << endl;
	cout << "    length:          " << Z.length() << endl;
	cout << "    cursor position: " << Z.position() << endl;
	cout << endl;
	if (!(A == Z)) {
		cout << "A and Z somehow not equal even though Z is a copy of A" << endl;
		exit(EXIT_FAILURE);
	}
	
	cout << "Element before cursor in A: " << A.peekPrev() << endl;
	cout << "Element after cursor in A: ";
	try {
		cout << A.peekNext() << endl;
		cout << "Test failed. Expected back sentinel node." << endl;
		exit(EXIT_FAILURE);
	} catch (range_error& e) {
		cout << "back sentinel node." << endl; 
	}
	
	cout << "Moving cursor in A to front of A... ";
	A.moveFront();
	cout << "Done. cursor now at position " << A.position() << " in list A." << endl << endl;
	if (A.front() != A.peekNext()) {
		cout << "Front element and element after cursor at front somehow not identical" << endl;
		exit(EXIT_FAILURE);
	}
	
	cout << "Trying to move cursor in A farther to the front... ";
	try {
		A.movePrev();
		cout << "Test failed. Expected to not be able to move farther front." << endl;
		exit(EXIT_FAILURE);
	} catch (range_error& e) {
		cout << "Cursor already at front - cannot move further front." << endl << endl;
	}
	
	cout << "Trying setBefore() and setAfter() with cursor at front of list... ";
	try {
		A.setBefore(0);
		cout << "Test failed. Expected to not be able to set value of front sentinel node." << endl;
		exit(EXIT_FAILURE);
	} catch (range_error& e) {
		cout << "Value of front sentinel node left unchanged." << endl;
	}
	A.setAfter(0);
	cout << "List A: " << A << endl;
	cout << "Length of A: " << A.length() << endl << endl;
	
	
	cout << "Moving cursor to the middle of list A... ";
	while (A.position() < A.length() / 2) {
		cout << "passing over " << A.moveNext() << endl;
	}
	cout << "Done. ";
	cout << "Cursor position: " << A.position() << " | ";
	cout << "Before cursor: " << A.peekPrev() << " | After cursor: " << A.peekNext() << endl << endl;
	
	cout << "Inserting numbers into list... ";
	A.insertBefore(42);
	A.insertAfter(1337);
	cout << "Done. ";
	cout << "Cursor position: " << A.position() << " | ";
	cout << "Before cursor: " << A.peekPrev() << " | After cursor: " << A.peekNext() << endl;
	cout << "List A: " << A << endl;
	cout << "Length of A: " << A.length() << endl << endl;
	
	cout << "Changing inserted numbers... ";
	A.setBefore(93);
	A.setAfter(95);
	cout << "Done. ";
	cout << "Cursor position: " << A.position() << " | ";
	cout << "Before cursor: " << A.peekPrev() << " | After cursor: " << A.peekNext() << endl;
	cout << "List A: " << A << endl;
	cout << "Length of A: " << A.length() << endl << endl;
	
	cout << "Removing numbers from middle of list... ";
	A.eraseBefore();
	A.eraseAfter();
	cout << "Done. ";
	cout << "Cursor position: " << A.position() << " | ";
	cout << "Before cursor: " << A.peekPrev() << " | After cursor: " << A.peekNext() << endl;
	cout << "List A: " << A << endl;
	cout << "Length of A: " << A.length() << endl << endl;
	
	cout << "Removing 2 numbers from front of list... ";
	while (A.position() > 1) {
		A.movePrev();
	}
	A.eraseBefore();
	if (A.position() != 0) {
		cout << "Cursor position after deletion of front using eraseBefore() incorrect" << endl;
		exit(EXIT_FAILURE);
	}
	A.eraseAfter();
	if (A.position() != 0) {
		cout << "Cursor position after deletion of front using eraseAfter() incorrect" << endl;
		exit(EXIT_FAILURE);
	}
	cout << "Done. ";
	cout << "Cursor position: " << A.position() << " | ";
	cout << "Before cursor: ";
	try {
		cout << A.peekPrev() << endl;
		cout << "Test failed. Expected front sentinel node." << endl;
		exit(EXIT_FAILURE);
	} catch (range_error& e) {
		cout << "front sentinel node";
	}
	cout << " | After cursor: " << A.peekNext() << endl;
	cout << "List A: " << A << endl;
	cout << "Length of A: " << A.length() << endl << endl;
	
	cout << "Removing 2 numbers from back of list... ";
	while (A.position() < A.length() - 1) {
		A.moveNext();
	}
	A.eraseAfter();
	if (A.position() != A.length()) {
		cout << "Cursor position or list length after deletion of back using eraseAfter() incorrect" << endl;
		exit(EXIT_FAILURE);
	}
	A.eraseBefore();
	if (A.position() != A.length()) {
		cout << "Cursor position or list length after deletion of back using eraseBefore() incorrect" << endl;
		exit(EXIT_FAILURE);
	}
	cout << "Done. ";
	cout << "Cursor position: " << A.position() << " | ";
	cout << "Before cursor: " << A.peekPrev();
	cout << " | After cursor: ";
	try {
		cout << A.peekNext() << endl;
		cout << "Test failed. Expected back sentinel node." << endl;
		exit(EXIT_FAILURE);
	} catch (range_error& e) {
		cout << "back sentinel node" << endl;
	}
	cout << "List A: " << A << endl;
	cout << "Length of A: " << A.length() << endl;
	cout << endl;
	cout << endl;
	
	cout << "Element before cursor in B: ";
	try {
		cout << B.peekPrev() << endl;
		cout << "Test failed. Expected front sentinel node." << endl;
		exit(EXIT_FAILURE);
	} catch (range_error& e) {
		cout << "front sentinel node." << endl; 
	}
	cout << "Element after cursor in B: " << B.peekNext() << endl;
	
	cout << "Moving cursor in B to back of B... ";
	B.moveBack();
	cout << "Done. cursor now at position " << B.position() << " in list B." << endl;
	if (B.back() != B.peekPrev()) {
		cout << "Back element and element before cursor at back somehow not identical" << endl;
		exit(EXIT_FAILURE);
	}
	
	cout << "Trying to move cursor in B farther to the back... ";
	try {
		B.moveNext();
		cout << "Test failed. Expected to not be able to move farther back." << endl << endl;
		exit(EXIT_FAILURE);
	} catch (range_error& e) {
		cout << "Cursor already at back - cannot move further back." << endl << endl;
	}
	
	cout << "Trying setBefore() and setAfter() with cursor at back of list... ";
	try {
		B.setAfter(0);
		cout << "Test failed. Expected to not be able to set value of back sentinel node." << endl;
		exit(EXIT_FAILURE);
	} catch (range_error& e) {
		cout << "Value of back sentinel node left unchanged." << endl;
	}
	B.setBefore(419);
	cout << "List B: " << B << endl;
	cout << "Length of B: " << B.length() << endl << endl;
	cout << endl;
	
	cout << "Moving cursor to the middle of list B... ";
	while (B.position() > B.length() / 2) {
		cout << "passing over " << B.movePrev() << endl;
	}
	cout << "Done. ";
	cout << "Cursor position: " << B.position() << " | ";
	cout << "Before cursor: " << B.peekPrev() << " | After cursor: " << B.peekNext() << endl << endl;
	
	cout << "Clearing out A and B... ";
	A.clear();
	B.clear();
	int clearFailCount = 0;
	if (A.length() != 0) {
		cout << endl;
		cout << "Length of A is not 0 after clearing";
		clearFailCount += 1;
	}
	if (A.position() != 0) {
		cout << endl;
		cout << "Cursor in A is not at position 0 after clearing";
		clearFailCount += 1;
	}
	if (B.length() != 0) {
		cout << endl;
		cout << "Length of A is not 0 after clearing";
		clearFailCount += 1;
	}
	if (B.position() != 0) {
		cout << endl;
		cout << "Cursor in B is not at position 0 after clearing";
		clearFailCount += 1;
	}
	if (clearFailCount > 0) {
		cout << endl;
		exit(EXIT_FAILURE);
	}
	cout << "Done." << endl;
	cout << "List A: " << A << endl;
	cout << "List B: " << B << endl << endl;
	
	cout << "Concatenating the empty lists... ";
	List D = A.concat(B);
	if (D.position() != 0) {
		cout << endl << "Cursor of resulting list not at position 0" << endl;
		exit(EXIT_FAILURE);
	}
	if (D.length() > 0) {
		cout << endl << "Length of concatenation of two empty lists somehow not 0" << endl;
		exit(EXIT_FAILURE);
	}
	cout << "Done. A and B concatenated into D. List D: " << D << endl << endl;
	
	cout << "Populating A with numbers... ";
	for (int i = 1; i <= 5; i += 1) {
		A.insertBefore(i);
		A.insertBefore(i);
	}
	A.moveFront();
	cout << "Done." << endl;
	cout << "List A: " << A << endl << endl;
	
	cout << "Searching for first instance of 3 from front... ";
	A.findNext(3);
	if (A.position() != 5) {
		cout << "Cursor not in expected position" << endl;
		exit(EXIT_FAILURE);
	}
	if (A.peekPrev() != 3) {
		cout << "Cursor found after a value that is not the specified search target" << endl;
		exit(EXIT_FAILURE);
	}
	cout << "Done." << endl;
	cout << "Cursor position: " << A.position() << " | ";
	cout << "Before cursor: " << A.peekPrev();
	cout << " | After cursor: " << A.peekNext() << endl;
	
	cout << "Removing duplicates from A... ";
	A.cleanup();
	if (A.position() != 3) {
		cout << "Cursor not in correct position after clean up" << endl;
		exit(EXIT_FAILURE);
	}
	if (A.peekPrev() != 3) {
		cout << "Element before cursor after clean up is incorrect" << endl;
		exit(EXIT_FAILURE);
	}
	if (A.peekNext() != 4) {
		cout << "Element after cursor after clean up is incorrect" << endl;
		exit(EXIT_FAILURE);
	}
	cout << "Done." << endl;
	cout << "List A: " << A << endl;
	cout << "Cursor position: " << A.position() << " | ";
	cout << "Before cursor: " << A.peekPrev();
	cout << " | After cursor: " << A.peekNext() << endl << endl;
	
	cout << "Concatenating A to itself to make E... ";
	List E = A.concat(A);
	if (E.length() != 2 * A.length()) {
		cout << "Length of E incorrect" << endl;
		exit(EXIT_FAILURE);
	}
	if (E.position() != 0) {
		cout << "Cursor of E in wrong position" << endl;
		exit(EXIT_FAILURE);
	}
	cout << "Done." << endl;
	cout << "List E: " << E << endl;
	cout << "Cursor position: " << E.position() << endl << endl;
	
	cout << "Populating B with numbers... ";
	for (int i = 10; i >= 6; i -= 1) {
		B.insertAfter(i);
		B.insertAfter(i);
	}
	B.moveBack();
	cout << "Done." << endl;
	cout << "List B: " << B << endl << endl;
	
	cout << "Searching for first instance of 7 from back... ";
	B.findPrev(7);
	if (B.position() != 3) {
		cout << "Cursor not in expected position" << endl;
		exit(EXIT_FAILURE);
	}
	if (B.peekNext() != 7) {
		cout << "Cursor found before a value that is not the specified search target" << endl;
		exit(EXIT_FAILURE);
	}
	cout << "Done." << endl;
	cout << "Cursor position: " << B.position() << " | ";
	cout << "Before cursor: " << B.peekPrev();
	cout << " | After cursor: " << B.peekNext() << endl;
	
	cout << "Removing duplicates from B... ";
	B.cleanup();
	if (B.position() != 2) {
		cout << "Cursor not in correct position after clean up" << endl;
		exit(EXIT_FAILURE);
	}
	cout << "Done." << endl;
	cout << "List B: " << B << endl;
	cout << "Cursor position: " << B.position() << " | ";
	cout << "Before cursor: " << B.peekPrev();
	cout << " | After cursor: " << B.peekNext() << endl << endl;
	
	cout << "Concatenating B to A to make F... ";
	List F = A.concat(B);
	if (F.length() != A.length() + B.length()) {
		cout << "Length of F incorrect" << endl;
		exit(EXIT_FAILURE);
	}
	if (F.position() != 0) {
		cout << "Cursor of F in wrong position" << endl;
		exit(EXIT_FAILURE);
	}
	cout << "Done." << endl;
	cout << "List F: " << F << endl;
	cout << "Cursor position: " << F.position() << endl << endl;
	
	cout << "Testing cursor position at the ends of the list after clean up... ";
	List G, H;	
	
	for (int g = 1; g <= 5; g += 1) {
		G.insertBefore(g);
		G.insertBefore(g);
		if (g % 2 == 1) {
			G.insertBefore(g);
		}
	}
	G.cleanup();
	if (G.position() != 5) {
		cout << "Cursor position in list G not correct after clean up" << endl;
		exit(EXIT_FAILURE);
	}
	if (G.peekPrev() != G.back()) {
		cout << "Element before cursor in G does not match with expected element" << endl;
		exit(EXIT_FAILURE);
	}
	
	for (int h = 1; h <= 5; h += 1) {
		H.insertAfter(h);
		H.insertAfter(h);
		if (h % 2 == 1) {
			H.insertAfter(h);
		}
	}
	H.cleanup();
	if (H.position() != 0) {
		cout << "Cursor position in list H not correct after clean up" << endl;
		exit(EXIT_FAILURE);
	}
	if (H.peekNext() != H.front()) {
		cout << "Element after cursor in H does not match with expected element" << endl;
		exit(EXIT_FAILURE);
	}
	
	cout << "Done." << endl;
	cout << "List G: " << G << endl;
	cout << "Cursor position: " << G.position() << endl;
	cout << "Done." << endl;
	cout << "List H: " << H << endl;
	cout << "Cursor position: " << H.position() << endl << endl;
	
	cout << endl;
	return EXIT_SUCCESS;
}
