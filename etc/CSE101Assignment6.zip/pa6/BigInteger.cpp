/******************************************************************************
 * Name:       Sirapat "Poom" Phunjamaneechot                                 *
 * CruzID:     sphunjam                                                       *
 * PA6, CSE 101 Spring 2022                                                   *
 *                                                                            *
 * BigInteger.cpp                                                             *
 * Implementation of the BigInteger ADT                                       *
 ******************************************************************************/
 
#include<iostream>
#include<string>
#include<cstdlib>
#include<stdexcept>
#include"BigInteger.h"

// Global Constants --------------------------------------------------------

const long base = 1000000000;
const int power = 9;

// Class Constructors & Destructors ----------------------------------------

// BigInteger()
// Constructor that creates a new BigInteger in the zero state: 
// signum=0, digits=().
BigInteger::BigInteger() {
	signum = 0;
}

// BigInteger()
// Constructor that creates a new BigInteger from the string s.
// Pre: s is a non-empty string consisting of (at least one) base 10 digit
// {0,1,2,3,4,5,6,7,8,9}, and an optional sign {+,-} prefix.
BigInteger::BigInteger(std::string s) {
	if (s == "") {
		throw std::invalid_argument("BigInteger: Constructor: empty string");
	}
	
	signum = 0;
	digits.moveFront();
	
	if (s.length() == 1 && !std::isdigit(s[0])) {
		throw std::invalid_argument("BigInteger: Constructor: non-numeric string");
	}
	
	unsigned int startIndex = 0;
	if (s[0] == '+') {
		startIndex = 1;
	} else if (s[0] == '-') {
		startIndex = 1;
		signum = -1;
	}
	
	for (unsigned long i = startIndex; i < s.length(); i += 1) {
		int newValue = s[i] - '0';
		// If the difference between s[i] and '0' is not within [0, 9], then s[i] is not a decimal digit
		if (newValue < 0 || newValue > 9) {
			throw std::invalid_argument("BigInteger: Constructor: non-numeric string");
		}
		// Create a new digit at the beginning, or whenever the number of remaining decimal digits
		// perfectly divisible by power.
		if (i == startIndex || ((s.length() - startIndex) - (i - startIndex)) % power == 0) {
			digits.insertAfter(newValue);
			continue;
		}
		ListElement current = digits.peekNext();
		digits.setAfter(10 * current + newValue);
	}
	
	digits.moveBack();
	while (digits.length() > 0 && digits.peekPrev() == 0) {
		digits.eraseBefore();
	}
	
	if (digits.length() == 0) {
		signum = 0;
	} else if (signum != -1) {
		signum = 1;
	}
}

// BigInteger()
// Constructor that creates a copy of N.
BigInteger::BigInteger(const BigInteger& N) {
	signum = N.signum;
	digits = N.digits;
}

// Optional Destuctor
// ~BigInteger()
// ~BigInteger();

// Helper functions --------------------------------------------------------

// negateList()
// Changes the sign of each integer in List L. Used by sub().
void negateList(List& L) {
	L.moveFront();
	while (L.position() < L.length()) {
		int num = L.moveNext();
		L.setBefore(-1 * num);
	}
}

// sumList()
// Overwrites the state of S with A + sgn*B (considered as vectors).
// Used by both sum() and sub().
void sumList(List& S, List A, List B, int sgn) {
	S.clear();
	
	A.moveFront();
	B.moveFront();
	ListElement digitSum;
	
	while (A.position() < A.length() && B.position() < B.length()) {
		digitSum = A.moveNext() + (sgn * B.moveNext());
		S.insertBefore(digitSum);
	}
	
	while (A.position() < A.length()) {
		S.insertBefore(A.moveNext());
	}
	
	while (B.position() < B.length()) {
		S.insertBefore(sgn * (B.moveNext()));
	}
}

// normalizeList()
// Performs carries from right to left (least to most significant
// digits), then returns the sign of the resulting integer. Used
// by add(), sub() and mult().
int normalizeList(List& L) {
	long carry = 0;
	L.moveFront();
	
	ListElement digit;
	
	while (L.position() < L.length()) {
		digit = L.moveNext();
		L.setBefore(digit + carry);
		digit = L.peekPrev();
		carry = digit / base;
		digit = digit % base;
		
		if (digit < 0) {
			// Dividing negative by positive seems to result in the ceiling rather than the floor,
			// so subtract 1 to get the floor, if not perfectly divisible.
			carry -= 1;
				
			// negative % positive is negative in C++
			// To get the value of the negative digit under modulus of the base,
			// add digit to base.
			digit += base;
		}
		
		L.setBefore(digit);
	}
	
	if (carry != 0) {
		int sign = (carry > 0) ? 1 : -1;
		L.insertBefore(sign * carry);
		return sign;
	} else {
		while (L.length() > 0 && L.peekPrev() == 0) {
			L.eraseBefore();
		}
		return (L.length() > 0) ? 1 : 0;
	}
}

// shiftList()
// Prepends p zero digits to L, multiplying L by base^p. Used by mult().
void shiftList(List& L, int p) {
	L.moveFront();
	for (int i = 0; i < p; i += 1) {
		L.insertAfter(0);
	}
}

// scalarMultList()
// Multiplies L (considered as a vector) by m. Used by mult().
void scalarMultList(List& L, ListElement m) {
	L.moveFront();
	while (L.position() < L.length()) {
		L.setBefore(m * L.moveNext());
	}
}

// Access functions --------------------------------------------------------

// sign()
// Returns -1, 1 or 0 according to whether this BigInteger is positive, 
// negative or 0, respectively.
int BigInteger::sign() const {
	return signum;
}

// compare()
// Returns -1, 1 or 0 according to whether this BigInteger is less than N,
// greater than N or equal to N, respectively.
int BigInteger::compare(const BigInteger& N) const {
	if (signum != N.signum) {
		if (signum == 0) {
			return -1 * N.signum;
		}
		return signum;
	}
	
	if (digits.length() > N.digits.length()) {
		return signum;
	} else if (digits.length() < N.digits.length()) {
		return signum * -1;
	} else {
		List A = digits;
		List B = N.digits;
		
		A.moveBack();
		B.moveBack();
		ListElement a;
		ListElement b;
		
		while (A.position() > 0) {
			a = A.movePrev();
			b = B.movePrev();
			
			if (a > b) {
				return signum;
			} else if (a < b) {
				return signum * -1;
			}
		}
		
		return 0;
	}
}


// Manipulation procedures -------------------------------------------------

// makeZero()
// Re-sets this BigInteger to the zero state.
void BigInteger::makeZero() {
	signum = 0;
	digits.clear();
}

// negate()
// If this BigInteger is zero, does nothing, otherwise reverses the sign of 
// this BigInteger positive <-. negative. 
void BigInteger::negate() {
	signum *= -1;
}


// BigInteger Arithmetic operations ----------------------------------------

// add()
// Returns a BigInteger representing the sum of this and N.
BigInteger BigInteger::add(const BigInteger& N) const {
	
	// Case A: same sign
	if (sign() == N.sign()) {
		BigInteger S;
		sumList(S.digits, digits, N.digits, 1);
		S.signum = normalizeList(S.digits) * sign();
		return S;
	}
	
	// Case B: different signs
	else {
		if (sign() == 1) {
			BigInteger Npos = N;
			Npos.negate();
			return sub(Npos);
		} else {
			BigInteger pos = *this;
			pos.negate();
			return N.sub(pos);
		}
	}
}

// sub()
// Returns a BigInteger representing the difference of this and N.
BigInteger BigInteger::sub(const BigInteger& N) const {
	BigInteger D;
	
	// Case A: same sign
	if (sign() == N.sign() && sign() != 0) {
		sumList(D.digits, digits, N.digits, -1);
		if ((sign() == 1 && N > *this) || (sign() == -1 && N < *this)) {
			negateList(D.digits);
			D.signum = normalizeList(D.digits) * -1 * sign();
			return D;
		}
		D.signum = normalizeList(D.digits) * sign();
	}
	
	// Case B: different signs
	else {
		sumList(D.digits, digits, N.digits, 1);
		int sgn = (sign() == 0) ? (N.sign() * -1) : sign();
		D.signum = normalizeList(D.digits) * sgn;
	}
	
	return D;
}

// mult()
// Returns a BigInteger representing the product of this and N. 
BigInteger BigInteger::mult(const BigInteger& N) const {
	BigInteger P;
	int PSign = sign() * N.sign();
	if (PSign == 0) {
		return P;
	}
	
	BigInteger B = N;
	
	B.digits.moveFront();
	while (B.digits.position() < B.digits.length()) {
		List a = digits;
		ListElement b = B.digits.moveNext();
		scalarMultList(a, b);
		normalizeList(a);
		shiftList(a, B.digits.position() - 1);
		sumList(P.digits, P.digits, a, 1);
	}
	
	normalizeList(P.digits);
	P.signum = PSign;
	return P;
}


// Other Functions ---------------------------------------------------------

// to_string()
// Returns a string representation of this BigInteger consisting of its
// base 10 digits. If this BigInteger is negative, the returned string 
// will begin with a negative sign '-'. If this BigInteger is zero, the
// returned string will consist of the character '0' only.
std::string BigInteger::to_string() {
	std::string s = "";
	
	if (signum == 0) {
		s += "0";
		return s;
	} else if (signum < 0) {
		s += "-";
	}
	
	digits.moveBack();
	ListElement digit;
	while (digits.position() > 0) {
		digit = digits.movePrev();
		std::string digitString = std::to_string(digit);
		if (digits.position() < digits.length() - 1) {
			s.append(power - digitString.length(), '0');
		}
		s += digitString;
	}
	return s;
}


// Overriden Operators -----------------------------------------------------
   
// operator<<()
// Inserts string representation of N into stream.
std::ostream& operator<<( std::ostream& stream, BigInteger N ) {
	return stream << N.BigInteger::to_string();
}

// operator==()
// Returns true if and only if A equals B. 
bool operator==( const BigInteger& A, const BigInteger& B ) {
	return A.compare(B) == 0;
}

// operator<()
// Returns true if and only if A is less than B. 
bool operator<( const BigInteger& A, const BigInteger& B ) {
	return A.compare(B) < 0;
}

// operator<=()
// Returns true if and only if A is less than or equal to B. 
bool operator<=( const BigInteger& A, const BigInteger& B ) {
	return A.compare(B) <= 0;
}

// operator>()
// Returns true if and only if A is greater than B. 
bool operator>( const BigInteger& A, const BigInteger& B ) {
	return A.compare(B) > 0;
}

// operator>=()
// Returns true if and only if A is greater than or equal to B. 
bool operator>=( const BigInteger& A, const BigInteger& B ) {
	return A.compare(B) >= 0;
}

// operator+()
// Returns the sum A+B. 
BigInteger operator+( const BigInteger& A, const BigInteger& B ) {
	return A.add(B);
}

// operator+=()
// Overwrites A with the sum A+B. 
BigInteger operator+=( BigInteger& A, const BigInteger& B ) {
	return A = A.add(B);
}

// operator-()
// Returns the difference A-B. 
BigInteger operator-( const BigInteger& A, const BigInteger& B ) {
	return A.sub(B);
}

// operator-=()
// Overwrites A with the difference A-B. 
BigInteger operator-=( BigInteger& A, const BigInteger& B ) {
	return A = A.sub(B);
}

// operator*()
// Returns the product A*B. 
BigInteger operator*( const BigInteger& A, const BigInteger& B ) {
	return A.mult(B);
}

// operator*=()
// Overwrites A with the product A*B. 
BigInteger operator*=( BigInteger& A, const BigInteger& B ) {
	return A = A.mult(B);
}
